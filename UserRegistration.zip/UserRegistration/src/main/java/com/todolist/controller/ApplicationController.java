package com.todolist.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.todolist.model.User;
import com.todolist.services.UserService;

@Controller
public class ApplicationController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/welcome")
	public String Welcome()
	{
		return "welcomepage.jsp" ;
	}
	@RequestMapping("/register")
	public String register()
	{
		return "UserRegistration.jsp" ;
	}
	
	@RequestMapping("/show-users")
	public String showAllUsers(Model model)
	{
		model.addAttribute("users", userService.showAllUsers());
		return "UserList.jsp" ;
	}
	
	
	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request)
	{
		userService.saveMyUser(user);
		request.setAttribute("users", userService.showAllUsers());
		return "UserList.jsp" ;
	}
	
	@RequestMapping("/delete-user")
	public String deleteUser(HttpServletRequest request, @RequestParam("id") Integer id)
	{
		userService.deleteUser(id);
		request.setAttribute("users", userService.showAllUsers()); 	
		return "UserList.jsp";
	}
	
	@RequestMapping("/update-user")
	public String updateUser(HttpServletRequest request, @RequestParam("id") Integer id)
	{
		request.setAttribute("user", userService.updateUser(id));
		request.setAttribute("users", userService.showAllUsers()); 	
		return "EditUser.jsp";
	}
	
}
