package com.todolist.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.todolist.model.User;
import com.todolist.repository.UserRepository;

@Service
@Transactional
public class UserService {
	
	private final UserRepository userRepository;
	
	public UserService(UserRepository userRepository)
	{
		this.userRepository=userRepository;
	}
	
	public void saveMyUser(User user)
	{
		userRepository.save(user);
	}
	public List<User> showAllUsers()
	{
		List<User> users = new ArrayList();
		for(User user:userRepository.findAll())
		{
			users.add(user);
		}
		return users;	
	}
	
	public void deleteUser(Integer id)
	{
		userRepository.deleteById(id);
	}
    
	public User updateUser(Integer id)
	{
		
		return userRepository.findById(id).orElse(null);
	}

}
